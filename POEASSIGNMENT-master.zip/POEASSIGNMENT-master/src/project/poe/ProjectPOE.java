/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package project.poe;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import java.awt.Color;
import javax.swing.text.NumberFormatter;
import java.text.NumberFormat;


/**
 *
 * @author RC_Student_lab
 */
public class ProjectPOE implements ActionListener{

    
    private static JLabel userlabel;
    private static JTextField userText;
    private static JLabel passwordLabel;
    private static JPasswordField passwordText;
    private static JLabel NumberLabel;
    private static JFormattedTextField numField;
    private static JButton button;
    private static JLabel success;
    private static JButton anotherButton;
    private static String registeredUsername ="";
    private static String registeredPassword ="";
    private static String registeredPhone ="";
    private static JPanel panel;
    
    

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       //thsi the panelwindow that holds the labels and fields 
       panel = new JPanel();
       JFrame frame = new JFrame();
       frame.setSize(350, 200);
       frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       
       frame.add(panel);
       //username label
       panel.setLayout(null);
       userlabel =new JLabel("Username");
       userlabel.setBounds(10, 20, 80, 25);
       panel.add(userlabel);
       
       //user text field the user will type in here
       userText =new JTextField(20);
       userText.setBounds(100, 20 ,165, 25);
       panel.add(userText);
       
       //password label
       passwordLabel = new JLabel("Password");
       passwordLabel.setBounds(10,50,80,25);
       panel.add(passwordLabel);
       
       //user text field the password will not be visible
       passwordText = new JPasswordField();
       passwordText.setBounds(100,50,165,25);
       panel.add(passwordText);
       JLabel transcript = new JLabel();
       transcript.setBounds(10,140,300,25);
       panel.add(transcript);
       
       //phone number label
       NumberLabel = new JLabel("SANumber +27");
       NumberLabel.setBounds(10,75,100,25);
       panel.add(NumberLabel);
       
       //phonenumber format this field only allows numbers in it but not start with 0
       NumberFormat format =NumberFormat.getIntegerInstance();
       format.setGroupingUsed(false);
       NumberFormatter formatter = new NumberFormatter(format);
       formatter.setValueClass(Integer.class);
       formatter.setAllowsInvalid(false);
       
       numField =new JFormattedTextField(formatter);
       numField.setBounds(100,80,165,25);
       panel.add(numField);
       
       //this is the button for sign up
       button = new JButton("Register");
       button.setBounds(10,130,85,25);
       button.addActionListener(new ProjectPOE());
       panel.add(button);
       
       //succes is the button working when pressed
       success = new JLabel("");
       success.setBounds(10,110,300,25);
       panel.add(success);
       
       //this the another button for login
       anotherButton = new JButton("Login");
       anotherButton.setBounds(150,130,80,25);
       anotherButton.addActionListener(new ProjectPOE());
       panel.add(anotherButton);
       
       
               
       
       
       
       
       
       
       //sets the visibility for the labels, field and buttons
       frame.setVisible(true); 
    }

    @Override
    public void actionPerformed(ActionEvent e) {
       String Username =userText.getText();
       String password = new String(passwordText.getPassword());
       String number = numField.getText();
        
       boolean hasUnderscore =Username.contains("_");
       boolean usernamelongEnough = Username.length()>=5;
       boolean validUsername =hasUnderscore &&usernamelongEnough;
       
       boolean hasUpper =password.matches(".*[A-Z].*");
       boolean hasNumber =password.matches(".*[0-9].*");
       boolean hasSpecial =password.matches(".*[!@#$%^&*()].*");
       boolean passwordlongEnough =password.length()>=8;
       boolean validpassword = hasUpper && hasNumber && hasSpecial && passwordlongEnough;
       boolean isNineDigits = number.matches("\\d{8}");
  
       //if the user name is not valid the they will be a red message that will show up 
       if(!validUsername){
           success.setForeground(Color.red);
           if(!hasUnderscore && !passwordlongEnough){
            success.setText("Username should have 5 characters and have a underscore.");
           }
           //else if the username those not have underscore show error message
           else if(!hasUnderscore){
           success.setText("username should have an underscore.");
           }
           //else the username does not have 5 characters show message
       else{
           success.setText("Username must have 5 characters");
           }
           return;
           //if the password is not valid it will show a red error message
       }
       if (!validpassword){
           success.setForeground(Color.red);
           success.setText("password must at least be 8 characters long");
          return;
       }
       //when the didits in the field is not 8digits show red error message
         if(isNineDigits){
           success.setForeground(Color.red);
           success.setText("phone number must be 8 digits.");
          return;
         }
         //this will register the users input data  
           registeredUsername = Username;
           registeredPassword =password;
           registeredPhone =number;
           
           //after everything has been entred correctly it will display a green message that show the user that the sign up is successfull 
           success.setForeground(Color.green);
           success.setText("signup successful\nPhone+27" +number);
       
           //this when the login button is been pressed with the the signup is done it willl remove all from the panel
           if(e.getSource()==anotherButton){
               panel.removeAll();
               panel.repaint();
               panel.revalidate();
           
               //A new panel will be shown with new labels and fields
            //loginuser label
           JLabel LoginUserlabel = new JLabel("Username");
           LoginUserlabel.setBounds(50,30,80,25);
           panel.add(LoginUserlabel);
           
           //loginuser text field 
           JTextField LoginUserField = new JTextField(20);
           LoginUserField.setBounds(140,30,160,25);
           panel.add(LoginUserField);
           
           //login password label
           JLabel LoginpasswordLabel = new JLabel("Password");
           LoginpasswordLabel.setBounds(50,70,80,25);
           panel.add(LoginpasswordLabel);
           
           //login password field
           JPasswordField LoginpasswordField =new JPasswordField();
           LoginpasswordField.setBounds(140,70,160,25);
           panel.add(LoginpasswordField);
           
           //login message label 
           JLabel LoginMessage = new JLabel("");
           LoginMessage.setBounds(10,110,300,25);
           panel.add(LoginMessage);
           
           //this is the login button
           JButton SubmitLoginButton =new JButton("Login");
           SubmitLoginButton.setBounds(120,130,100,25);
           panel.add(SubmitLoginButton);
           
           
           SubmitLoginButton.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent evt){
                //declare the entered strings
                String enteredUser =LoginUserField.getText();
                String enteredPass = new String(LoginpasswordField.getPassword());
                
                //this when the users detail are equal to the registered saved data
                if(enteredUser.equals(registeredUsername) && enteredPass.equals(registeredPassword)){
                    LoginMessage.setForeground(Color.green);
                    LoginMessage.setText("Login Successfull");
                    }
                //if the detail is not correct it should show an error message
                else{
                    LoginMessage.setForeground(Color.red);
                    LoginMessage.setText("Incorrect Username or Password");
                }
            }
               
           });
           panel.repaint();
           panel.revalidate();
           
                   }
    }
         }
    

